# Resturaunt Front End Project

## Functionality 

### This project is purely for demonstrating the usefullness of Bootstrap for front end development. 

Its is comprised by a series of html pages, mainly the '''html index.html''' home page that displays a navigation bar, a image carousel function, the typical bootstrap grid function, the CTA Button function, and finally a simple text footer. 

There are two CTA Buttons '''html Menu / Hiring Form''' the '''Menu''' button is simply for display whilst the '''Hiring Form''' button will route the user to the '''html hiring.html'''. The hiring page displays a form that will accept user information and briefly display a simple submission popup when the button is pressed. 

